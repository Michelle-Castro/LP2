﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_IMC
{
    public partial class Form1 : Form
    {
        public Double altura, peso, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            txtIMC.Text = imc.ToString("N2");

            if (imc < 18.5)
            {
                MessageBox.Show("Classificação: Magreza");
                MessageBox.Show("Grau de Obesidade: o");
            }
            else
                if (imc >= 18.5 && imc <= 24.9)
            {
                MessageBox.Show("Classificação: Normal");
                MessageBox.Show("Grau de Obesidade: o");
            }
            else
                if (imc >= 25 && imc <= 29.9)
            {
                MessageBox.Show("Classificação: Sobrepeso");
                MessageBox.Show("Grau de Obesidade: I");
            }
            else
                if (imc >= 30 && imc <= 39.9)
            {
                MessageBox.Show("Classificação: Obesidade");
                MessageBox.Show("Grau de Obesidade: II");
            }
            else
                if (imc >= 40)
            {
                MessageBox.Show("Classificação: Obesidade Grave");
                MessageBox.Show("Grau de Obesidade: III");
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Valor Inválido!");
                txtAltura.Text = "";
                txtAltura.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtIMC.Clear();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Valor Inválido!");
                txtPeso.Text = "";
                txtPeso.Focus();
            }
        }
    }
}
