﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        public Double Num1, Num2, Num3;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtNum3.Clear();
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out Num1))
            {
                MessageBox.Show("Valor Inválido!");
                txtNum1.Text = "";
                txtNum1.Focus();
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out Num2))
            {
                MessageBox.Show("Valor Inválido!");
                txtNum2.Text = "";
                txtNum2.Focus();
            }
        }

        private void txtNum3_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum3.Text, out Num3))
            {
                MessageBox.Show("Valor Inválido!");
                txtNum3.Text = "";
                txtNum3.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

                if (((Num2 - Num3) < Num1 && Num1 < (Num2 + Num3)) &&
                    ((Num1 - Num3) < Num2 && Num2 < (Num1 + Num3)) &&
                    ((Num1 - Num2) < Num3 && Num3 < (Num1 + Num2)))
                {
                    if (Num1 == Num2 && Num1 == Num3)
                    {
                        MessageBox.Show("Triângulo Equilátero.");
                    }
                    else
                    if (Num1 == Num2 || Num1 == Num3 || Num2 == Num3)
                    {
                        MessageBox.Show("Triângulo Isósceles.");
                    }
                    else
                    if (Num1 != Num2 && Num1 != Num3 && Num2 != Num3)
                    {
                        MessageBox.Show("Triângulo Escaleno.");
                    }
                }
                else
                {
                    MessageBox.Show("Não forma um triângulo!");
                }
            
        }

    }
}
