﻿
namespace Salario
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblINSS = new System.Windows.Forms.Label();
            this.lblIRPF = new System.Windows.Forms.Label();
            this.lblFamilia = new System.Windows.Forms.Label();
            this.lblLiquido = new System.Windows.Forms.Label();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.mtxtSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.mtxtFilhos = new System.Windows.Forms.MaskedTextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnVerificarDesc = new System.Windows.Forms.Button();
            this.gbSexo = new System.Windows.Forms.GroupBox();
            this.rbtnM = new System.Windows.Forms.RadioButton();
            this.rbtnF = new System.Windows.Forms.RadioButton();
            this.cbxCasado = new System.Windows.Forms.CheckBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.mtxtAliqINSS = new System.Windows.Forms.MaskedTextBox();
            this.mtxtAliqIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mtxtSalFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mtxtSalLiq = new System.Windows.Forms.MaskedTextBox();
            this.mtxtDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.mtxtDescIRPF = new System.Windows.Forms.MaskedTextBox();
            this.gbSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(71, 27);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(123, 15);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do Funcionário";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(71, 71);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(74, 15);
            this.lblSalario.TabIndex = 1;
            this.lblSalario.Text = "Salário Bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(71, 119);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(101, 15);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Número de Filhos";
            // 
            // lblINSS
            // 
            this.lblINSS.AutoSize = true;
            this.lblINSS.Location = new System.Drawing.Point(71, 260);
            this.lblINSS.Name = "lblINSS";
            this.lblINSS.Size = new System.Drawing.Size(79, 15);
            this.lblINSS.TabIndex = 3;
            this.lblINSS.Text = "Alíquota INSS";
            // 
            // lblIRPF
            // 
            this.lblIRPF.AutoSize = true;
            this.lblIRPF.Location = new System.Drawing.Point(71, 305);
            this.lblIRPF.Name = "lblIRPF";
            this.lblIRPF.Size = new System.Drawing.Size(78, 15);
            this.lblIRPF.TabIndex = 4;
            this.lblIRPF.Text = "Alíquota IRPF";
            // 
            // lblFamilia
            // 
            this.lblFamilia.AutoSize = true;
            this.lblFamilia.Location = new System.Drawing.Point(71, 355);
            this.lblFamilia.Name = "lblFamilia";
            this.lblFamilia.Size = new System.Drawing.Size(83, 15);
            this.lblFamilia.TabIndex = 5;
            this.lblFamilia.Text = "Salário Família";
            // 
            // lblLiquido
            // 
            this.lblLiquido.AutoSize = true;
            this.lblLiquido.Location = new System.Drawing.Point(71, 403);
            this.lblLiquido.Name = "lblLiquido";
            this.lblLiquido.Size = new System.Drawing.Size(85, 15);
            this.lblLiquido.TabIndex = 6;
            this.lblLiquido.Text = "Salário Líquido";
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.Location = new System.Drawing.Point(93, 214);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(0, 15);
            this.lblMensagem.TabIndex = 7;
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(419, 242);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(84, 15);
            this.lblDescINSS.TabIndex = 8;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(419, 287);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(83, 15);
            this.lblDescIRPF.TabIndex = 9;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // mtxtSalarioBruto
            // 
            this.mtxtSalarioBruto.Location = new System.Drawing.Point(210, 68);
            this.mtxtSalarioBruto.Mask = "0000000,00";
            this.mtxtSalarioBruto.Name = "mtxtSalarioBruto";
            this.mtxtSalarioBruto.Size = new System.Drawing.Size(100, 23);
            this.mtxtSalarioBruto.TabIndex = 11;
            this.mtxtSalarioBruto.ValidatingType = typeof(int);
            this.mtxtSalarioBruto.Validated += new System.EventHandler(this.mtxtSalarioBruto_Validated);
            // 
            // mtxtFilhos
            // 
            this.mtxtFilhos.Location = new System.Drawing.Point(210, 116);
            this.mtxtFilhos.Mask = "00";
            this.mtxtFilhos.Name = "mtxtFilhos";
            this.mtxtFilhos.Size = new System.Drawing.Size(100, 23);
            this.mtxtFilhos.TabIndex = 12;
            this.mtxtFilhos.ValidatingType = typeof(int);
            this.mtxtFilhos.Validated += new System.EventHandler(this.mtxtFilhos_Validated);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(210, 24);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 23);
            this.txtNome.TabIndex = 13;
            // 
            // btnVerificarDesc
            // 
            this.btnVerificarDesc.Location = new System.Drawing.Point(200, 160);
            this.btnVerificarDesc.Name = "btnVerificarDesc";
            this.btnVerificarDesc.Size = new System.Drawing.Size(120, 27);
            this.btnVerificarDesc.TabIndex = 20;
            this.btnVerificarDesc.Text = "Verificar Desconto";
            this.btnVerificarDesc.UseVisualStyleBackColor = true;
            this.btnVerificarDesc.Click += new System.EventHandler(this.btnVerificarDesc_Click);
            // 
            // gbSexo
            // 
            this.gbSexo.Controls.Add(this.rbtnM);
            this.gbSexo.Controls.Add(this.rbtnF);
            this.gbSexo.Location = new System.Drawing.Point(385, 24);
            this.gbSexo.Name = "gbSexo";
            this.gbSexo.Size = new System.Drawing.Size(200, 126);
            this.gbSexo.TabIndex = 21;
            this.gbSexo.TabStop = false;
            this.gbSexo.Text = "Sexo";
            // 
            // rbtnM
            // 
            this.rbtnM.AutoSize = true;
            this.rbtnM.Location = new System.Drawing.Point(81, 88);
            this.rbtnM.Name = "rbtnM";
            this.rbtnM.Size = new System.Drawing.Size(36, 19);
            this.rbtnM.TabIndex = 1;
            this.rbtnM.TabStop = true;
            this.rbtnM.Text = "M";
            this.rbtnM.UseVisualStyleBackColor = true;
            // 
            // rbtnF
            // 
            this.rbtnF.AutoSize = true;
            this.rbtnF.Location = new System.Drawing.Point(81, 40);
            this.rbtnF.Name = "rbtnF";
            this.rbtnF.Size = new System.Drawing.Size(31, 19);
            this.rbtnF.TabIndex = 0;
            this.rbtnF.TabStop = true;
            this.rbtnF.Text = "F";
            this.rbtnF.UseVisualStyleBackColor = true;
            // 
            // cbxCasado
            // 
            this.cbxCasado.AutoSize = true;
            this.cbxCasado.Location = new System.Drawing.Point(456, 178);
            this.cbxCasado.Name = "cbxCasado";
            this.cbxCasado.Size = new System.Drawing.Size(65, 19);
            this.cbxCasado.TabIndex = 22;
            this.cbxCasado.Text = "Casado";
            this.cbxCasado.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(383, 370);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(120, 27);
            this.btnLimpar.TabIndex = 23;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(529, 370);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(120, 27);
            this.btnFechar.TabIndex = 24;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // mtxtAliqINSS
            // 
            this.mtxtAliqINSS.Enabled = false;
            this.mtxtAliqINSS.Location = new System.Drawing.Point(207, 257);
            this.mtxtAliqINSS.Name = "mtxtAliqINSS";
            this.mtxtAliqINSS.Size = new System.Drawing.Size(100, 23);
            this.mtxtAliqINSS.TabIndex = 25;
            // 
            // mtxtAliqIRPF
            // 
            this.mtxtAliqIRPF.Enabled = false;
            this.mtxtAliqIRPF.Location = new System.Drawing.Point(207, 302);
            this.mtxtAliqIRPF.Name = "mtxtAliqIRPF";
            this.mtxtAliqIRPF.Size = new System.Drawing.Size(100, 23);
            this.mtxtAliqIRPF.TabIndex = 26;
            // 
            // mtxtSalFamilia
            // 
            this.mtxtSalFamilia.Enabled = false;
            this.mtxtSalFamilia.Location = new System.Drawing.Point(207, 352);
            this.mtxtSalFamilia.Name = "mtxtSalFamilia";
            this.mtxtSalFamilia.Size = new System.Drawing.Size(100, 23);
            this.mtxtSalFamilia.TabIndex = 27;
            // 
            // mtxtSalLiq
            // 
            this.mtxtSalLiq.Enabled = false;
            this.mtxtSalLiq.Location = new System.Drawing.Point(207, 400);
            this.mtxtSalLiq.Name = "mtxtSalLiq";
            this.mtxtSalLiq.Size = new System.Drawing.Size(100, 23);
            this.mtxtSalLiq.TabIndex = 28;
            // 
            // mtxtDescINSS
            // 
            this.mtxtDescINSS.Enabled = false;
            this.mtxtDescINSS.Location = new System.Drawing.Point(538, 239);
            this.mtxtDescINSS.Name = "mtxtDescINSS";
            this.mtxtDescINSS.Size = new System.Drawing.Size(100, 23);
            this.mtxtDescINSS.TabIndex = 29;
            // 
            // mtxtDescIRPF
            // 
            this.mtxtDescIRPF.Enabled = false;
            this.mtxtDescIRPF.Location = new System.Drawing.Point(538, 284);
            this.mtxtDescIRPF.Name = "mtxtDescIRPF";
            this.mtxtDescIRPF.Size = new System.Drawing.Size(100, 23);
            this.mtxtDescIRPF.TabIndex = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 440);
            this.Controls.Add(this.mtxtDescIRPF);
            this.Controls.Add(this.mtxtDescINSS);
            this.Controls.Add(this.mtxtSalLiq);
            this.Controls.Add(this.mtxtSalFamilia);
            this.Controls.Add(this.mtxtAliqIRPF);
            this.Controls.Add(this.mtxtAliqINSS);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.cbxCasado);
            this.Controls.Add(this.gbSexo);
            this.Controls.Add(this.btnVerificarDesc);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.mtxtFilhos);
            this.Controls.Add(this.mtxtSalarioBruto);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.lblLiquido);
            this.Controls.Add(this.lblFamilia);
            this.Controls.Add(this.lblIRPF);
            this.Controls.Add(this.lblINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Salário";
            this.gbSexo.ResumeLayout(false);
            this.gbSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblINSS;
        private System.Windows.Forms.Label lblIRPF;
        private System.Windows.Forms.Label lblFamilia;
        private System.Windows.Forms.Label lblLiquido;
        private System.Windows.Forms.Label lblMensagem;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.MaskedTextBox mtxtSalarioBruto;
        private System.Windows.Forms.MaskedTextBox mtxtFilhos;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnVerificarDesc;
        private System.Windows.Forms.GroupBox gbSexo;
        private System.Windows.Forms.RadioButton rbtnM;
        private System.Windows.Forms.RadioButton rbtnF;
        private System.Windows.Forms.CheckBox cbxCasado;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.MaskedTextBox mtxtAliqINSS;
        private System.Windows.Forms.MaskedTextBox mtxtAliqIRPF;
        private System.Windows.Forms.MaskedTextBox mtxtSalFamilia;
        private System.Windows.Forms.MaskedTextBox mtxtSalLiq;
        private System.Windows.Forms.MaskedTextBox mtxtDescINSS;
        private System.Windows.Forms.MaskedTextBox mtxtDescIRPF;
    }
}

