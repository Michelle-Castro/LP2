﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salario
{
    public partial class Form1 : Form
    {
        public Double SalBruto, DescontoINSS, DescontoIRPF, AliquotaINSS, AliquotaIRPF, SalFamilia, SalLiquido;
        public int Filhos;
        public Form1()
        {
            InitializeComponent();
        }

        private void mtxtFilhos_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(mtxtFilhos.Text, out Filhos))
            {
                mtxtFilhos.Text = "";
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            mtxtSalarioBruto.Clear();
            mtxtFilhos.Clear();
            mtxtSalFamilia.Clear();
            mtxtAliqINSS.Clear();
            mtxtAliqIRPF.Clear();
            mtxtDescINSS.Clear();
            mtxtDescIRPF.Clear();
            mtxtSalLiq.Clear();
        }

        private void btnVerificarDesc_Click(object sender, EventArgs e)
        {

            if (SalBruto <= 800.47)
            {
                mtxtAliqINSS.Text = "7.65%";
                DescontoINSS = SalBruto * 0.0765;
            }
            else
                if (SalBruto <= 1050)
            {
                mtxtAliqINSS.Text = "8.65%";
                DescontoINSS = SalBruto * 0.0865;
            }
            else
                if (SalBruto <= 1400.77)
            {
                mtxtAliqINSS.Text = "9.00%";
                DescontoINSS = SalBruto * 0.09;
            }
            else
                if (SalBruto <= 2801.56)
            {
                mtxtAliqINSS.Text = "11.00%";
                DescontoINSS = SalBruto * 0.11;
            }
            else
                if (SalBruto > 2801.56)
            {
                mtxtAliqINSS.Text = "308.17";
                DescontoINSS = 308.17;
            }

            mtxtDescINSS.Text = DescontoINSS.ToString("N2");

            if (SalBruto <= 1257.12)
            {
                mtxtAliqIRPF.Text = "0";
                DescontoIRPF = 0;
            }
            else
                if (SalBruto <= 2512.08)
            {
                mtxtAliqIRPF.Text = "15%";
                DescontoIRPF = SalBruto * 0.15;
            }
            else
                if (SalBruto > 2512.08)
            {
                mtxtAliqIRPF.Text = "27.5%";
                DescontoIRPF = SalBruto * 0.275;
            }
            
            mtxtDescIRPF.Text = DescontoIRPF.ToString("N2");

            if (SalBruto <= 435.52)
            {
                SalFamilia = 22.33 * Filhos;
            }
            else
                if (SalBruto <= 654.61)
            {
                SalFamilia = 15.74 * Filhos;
            }
            else
                if (SalBruto > 654.61)
            {
                SalFamilia = 0;
            }

            mtxtSalFamilia.Text = SalFamilia.ToString("N2");

            
            lblMensagem.Visible = true;

            lblMensagem.Text = "Os descontos do salário ";

            if (rbtnF.Checked)
                lblMensagem.Text = lblMensagem.Text + "da Sra " + txtNome.Text;
            else
                lblMensagem.Text = lblMensagem.Text + "do Sr " + txtNome.Text;

            lblMensagem.Text = lblMensagem.Text + "que é ";

            if (cbxCasado.Checked)
                lblMensagem.Text = lblMensagem.Text + "casado(a) ";
            else
                lblMensagem.Text = lblMensagem.Text + "solteiro(a) ";

            lblMensagem.Text = lblMensagem.Text + "e que tem " +
                mtxtFilhos.SelectedText.ToString() + " filho(s) são:";

            SalLiquido = SalBruto - DescontoINSS - DescontoIRPF + SalFamilia;
            mtxtSalLiq.Text = SalLiquido.ToString("N2");
        }

        private void mtxtSalarioBruto_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mtxtSalarioBruto.Text, out SalBruto))
            {
                mtxtSalarioBruto.Text = "";
            }
        }
    }
}
