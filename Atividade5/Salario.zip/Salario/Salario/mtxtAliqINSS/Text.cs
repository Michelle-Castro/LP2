﻿namespace mtxtAliqINSS
{
    internal class Text
    {
    }
}