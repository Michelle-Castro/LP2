﻿
namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtCaracteres = new System.Windows.Forms.RichTextBox();
            this.btnQtdeNumero = new System.Windows.Forms.Button();
            this.btnCaracterPosicao = new System.Windows.Forms.Button();
            this.btnQtdeCaracter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtxtCaracteres
            // 
            this.rtxtCaracteres.Location = new System.Drawing.Point(148, 59);
            this.rtxtCaracteres.Name = "rtxtCaracteres";
            this.rtxtCaracteres.Size = new System.Drawing.Size(353, 135);
            this.rtxtCaracteres.TabIndex = 0;
            this.rtxtCaracteres.Text = "";
            // 
            // btnQtdeNumero
            // 
            this.btnQtdeNumero.Location = new System.Drawing.Point(148, 221);
            this.btnQtdeNumero.Name = "btnQtdeNumero";
            this.btnQtdeNumero.Size = new System.Drawing.Size(108, 53);
            this.btnQtdeNumero.TabIndex = 1;
            this.btnQtdeNumero.Text = "Quantidade de Números";
            this.btnQtdeNumero.UseVisualStyleBackColor = true;
            this.btnQtdeNumero.Click += new System.EventHandler(this.btnQtdeNumero_Click);
            // 
            // btnCaracterPosicao
            // 
            this.btnCaracterPosicao.Location = new System.Drawing.Point(269, 221);
            this.btnCaracterPosicao.Name = "btnCaracterPosicao";
            this.btnCaracterPosicao.Size = new System.Drawing.Size(108, 53);
            this.btnCaracterPosicao.TabIndex = 2;
            this.btnCaracterPosicao.Text = "1º Caracter e Posição";
            this.btnCaracterPosicao.UseVisualStyleBackColor = true;
            this.btnCaracterPosicao.Click += new System.EventHandler(this.btnCaracterPosicao_Click);
            // 
            // btnQtdeCaracter
            // 
            this.btnQtdeCaracter.Location = new System.Drawing.Point(393, 221);
            this.btnQtdeCaracter.Name = "btnQtdeCaracter";
            this.btnQtdeCaracter.Size = new System.Drawing.Size(108, 53);
            this.btnQtdeCaracter.TabIndex = 3;
            this.btnQtdeCaracter.Text = "Quantidade de Caracteres";
            this.btnQtdeCaracter.UseVisualStyleBackColor = true;
            this.btnQtdeCaracter.Click += new System.EventHandler(this.btnQtdeCaracter_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 366);
            this.Controls.Add(this.btnQtdeCaracter);
            this.Controls.Add(this.btnCaracterPosicao);
            this.Controls.Add(this.btnQtdeNumero);
            this.Controls.Add(this.rtxtCaracteres);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtCaracteres;
        private System.Windows.Forms.Button btnQtdeNumero;
        private System.Windows.Forms.Button btnCaracterPosicao;
        private System.Windows.Forms.Button btnQtdeCaracter;
    }
}