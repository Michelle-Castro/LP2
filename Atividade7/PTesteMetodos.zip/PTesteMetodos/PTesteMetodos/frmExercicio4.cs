﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQtdeNumero_Click(object sender, EventArgs e)
        {
            int contador = 0;
            char[] vetor = rtxtCaracteres.Text.ToCharArray();

            if(rtxtCaracteres.Text != "")
            {
                for (int i = 0; i < rtxtCaracteres.Text.Length; i++)
                {
                    if (Char.IsNumber(vetor[i]))
                    {
                        contador++;
                    }
                }
                MessageBox.Show("Quantidade de Números: " + contador);
            }
            else
            {
                MessageBox.Show("Não há números!");
            }
        }


        private void btnCaracterPosicao_Click(object sender, EventArgs e)
        {
            int contador = 0;

            while (contador < rtxtCaracteres.Text.Length)
            {
                if (Char.IsWhiteSpace(rtxtCaracteres.Text[contador]))
                    break;

                contador++;
            }
            contador = contador +1;
            MessageBox.Show("A posição do espaço em branco: " + contador);
        }

        private void btnQtdeCaracter_Click(object sender, EventArgs e)
        {
            char[] vetor = rtxtCaracteres.Text.ToCharArray();
            int contador = 0;

            foreach (char letra in vetor)
            {
                if (Char.IsLetter(letra))
                {
                    contador++;
                }
            }
            MessageBox.Show("Quantidade de Caracteres: " + contador);
        }
    }
}
