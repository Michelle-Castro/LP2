﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public int Numero1, Numero2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero2.Text, out Numero2) && Numero2 <= 0 && txtNumero2.Text != "")
            {
                MessageBox.Show("Número Incorreto!");
                txtNumero2.Text = "";
                txtNumero2.Focus();
            }
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            if (Numero1 < Numero2)
            {
                Random rdm = new Random();
                Double randomNumber = rdm.Next(Numero1, Numero2);
                MessageBox.Show(randomNumber.ToString());
            }
            else
                MessageBox.Show("Valores Incorretos!");
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero1.Text, out Numero1) && Numero1 <= 0 && txtNumero1.Text != "")
            {
                MessageBox.Show("Número Incorreto!");
                txtNumero1.Text = "";
                txtNumero1.Focus();
            }
        }
    }
}
