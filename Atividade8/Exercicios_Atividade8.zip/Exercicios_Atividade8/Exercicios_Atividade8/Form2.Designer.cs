﻿
namespace Exercicios_Atividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtFrase100 = new System.Windows.Forms.RichTextBox();
            this.btnEspacosBrancos = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnParLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtxtFrase100
            // 
            this.rtxtFrase100.Location = new System.Drawing.Point(43, 32);
            this.rtxtFrase100.Name = "rtxtFrase100";
            this.rtxtFrase100.Size = new System.Drawing.Size(522, 129);
            this.rtxtFrase100.TabIndex = 0;
            this.rtxtFrase100.Text = "";
            // 
            // btnEspacosBrancos
            // 
            this.btnEspacosBrancos.Location = new System.Drawing.Point(73, 194);
            this.btnEspacosBrancos.Name = "btnEspacosBrancos";
            this.btnEspacosBrancos.Size = new System.Drawing.Size(96, 40);
            this.btnEspacosBrancos.TabIndex = 1;
            this.btnEspacosBrancos.Text = "Espaços Brancos";
            this.btnEspacosBrancos.UseVisualStyleBackColor = true;
            this.btnEspacosBrancos.Click += new System.EventHandler(this.btnEspacosBrancos_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(244, 194);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(96, 40);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Letra R";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnParLetras
            // 
            this.btnParLetras.Location = new System.Drawing.Point(415, 194);
            this.btnParLetras.Name = "btnParLetras";
            this.btnParLetras.Size = new System.Drawing.Size(96, 40);
            this.btnParLetras.TabIndex = 3;
            this.btnParLetras.Text = "Par de Letras";
            this.btnParLetras.UseVisualStyleBackColor = true;
            this.btnParLetras.Click += new System.EventHandler(this.btnParLetras_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 270);
            this.Controls.Add(this.btnParLetras);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspacosBrancos);
            this.Controls.Add(this.rtxtFrase100);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtFrase100;
        private System.Windows.Forms.Button btnEspacosBrancos;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnParLetras;
    }
}