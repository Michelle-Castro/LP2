﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacosBrancos_Click(object sender, EventArgs e)
        {
            string qtdeEspacos;
            
            if (rtxtFrase100.TextLength <= 100)
            {
                qtdeEspacos = Convert.ToString(rtxtFrase100.Text.Count(Char.IsWhiteSpace));
                MessageBox.Show("O número de espaços é: " + qtdeEspacos);
            }else
            {
                MessageBox.Show("Digite até 100 caracteres!");
                rtxtFrase100.Clear();
            }
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int i = 0;
            
            if (rtxtFrase100.TextLength <= 100)
            {

                for (i = 0; i < rtxtFrase100.Text.Length; i++)
                {
                    if (rtxtFrase100.Text[i] == 'R' || rtxtFrase100.Text[i] == 'r')
                    {
                        contador++;
                    }
                }
                
                MessageBox.Show("Quantidade de vezes em que a letra 'R' aparece é: " + contador);
                
            }
            else
            {
                MessageBox.Show("Digite até 100 caracteres!");
                rtxtFrase100.Clear();
            }
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            char letraAntiga = '\0';
            int i = 0;
            
            if (rtxtFrase100.TextLength <= 100)
            {
                //trim tira espaços em branco
                foreach (char contador in rtxtFrase100.Text.Trim())
                {
                    if (contador == letraAntiga && contador != ' ')
                    {
                        i++;
                    }

                    letraAntiga = contador;
                }
                MessageBox.Show("Existem " + i + " pares de letras!");
            }
            else
            {
                MessageBox.Show("Digite até 100 caracteres!");
                rtxtFrase100.Clear();
            }
        }
    }
}
