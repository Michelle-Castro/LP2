﻿
namespace Exercicios_Atividade8
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumero = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.btnGerarNumero = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Location = new System.Drawing.Point(106, 67);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new System.Drawing.Size(107, 15);
            this.lblNumero.TabIndex = 0;
            this.lblNumero.Text = "Digite um número:";
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(253, 64);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(100, 23);
            this.txtNumero.TabIndex = 1;
            this.txtNumero.Validated += new System.EventHandler(this.txtNumero_Validated);
            // 
            // btnGerarNumero
            // 
            this.btnGerarNumero.Location = new System.Drawing.Point(190, 134);
            this.btnGerarNumero.Name = "btnGerarNumero";
            this.btnGerarNumero.Size = new System.Drawing.Size(99, 39);
            this.btnGerarNumero.TabIndex = 2;
            this.btnGerarNumero.Text = "Gerar Número";
            this.btnGerarNumero.UseVisualStyleBackColor = true;
            this.btnGerarNumero.Click += new System.EventHandler(this.btnGerarNumero_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 262);
            this.Controls.Add(this.btnGerarNumero);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.lblNumero);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Button btnGerarNumero;
    }
}