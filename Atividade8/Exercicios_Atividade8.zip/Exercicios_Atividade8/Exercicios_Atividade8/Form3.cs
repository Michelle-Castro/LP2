﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade8
{
    public partial class frmExercicio2 : Form
    {
        public int Numero;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtNumero_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero.Text, out Numero))
            {
                MessageBox.Show("Número Incorreto!");
                txtNumero.Text = "";
                txtNumero.Focus();
            }
        }

        private void btnGerarNumero_Click(object sender, EventArgs e)
        {
            Double H = 0;

            if (Numero > 0)
            {
                for(int i = 1; i <= Numero; i++)
                {
                    H += 1.0 / i;
                }
                MessageBox.Show("O número gerado é: " + H);
            }
            else
            {
                MessageBox.Show("Número Incorreto!");
            }  
        }
    }
}
