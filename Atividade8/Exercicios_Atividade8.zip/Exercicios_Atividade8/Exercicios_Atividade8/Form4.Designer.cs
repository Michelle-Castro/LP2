﻿
namespace Exercicios_Atividade8
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCaracteres = new System.Windows.Forms.Label();
            this.txtPalavraOuFrase = new System.Windows.Forms.TextBox();
            this.btnPalindromo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCaracteres
            // 
            this.lblCaracteres.AutoSize = true;
            this.lblCaracteres.Location = new System.Drawing.Point(12, 44);
            this.lblCaracteres.Name = "lblCaracteres";
            this.lblCaracteres.Size = new System.Drawing.Size(154, 15);
            this.lblCaracteres.TabIndex = 0;
            this.lblCaracteres.Text = "Digite uma frase ou palavra:";
            // 
            // txtPalavraOuFrase
            // 
            this.txtPalavraOuFrase.Location = new System.Drawing.Point(186, 41);
            this.txtPalavraOuFrase.Name = "txtPalavraOuFrase";
            this.txtPalavraOuFrase.Size = new System.Drawing.Size(347, 23);
            this.txtPalavraOuFrase.TabIndex = 1;
            // 
            // btnPalindromo
            // 
            this.btnPalindromo.Location = new System.Drawing.Point(246, 100);
            this.btnPalindromo.Name = "btnPalindromo";
            this.btnPalindromo.Size = new System.Drawing.Size(122, 40);
            this.btnPalindromo.TabIndex = 2;
            this.btnPalindromo.Text = "Palíndromo ou Não";
            this.btnPalindromo.UseVisualStyleBackColor = true;
            this.btnPalindromo.Click += new System.EventHandler(this.btnPalindromo_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 223);
            this.Controls.Add(this.btnPalindromo);
            this.Controls.Add(this.txtPalavraOuFrase);
            this.Controls.Add(this.lblCaracteres);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCaracteres;
        private System.Windows.Forms.TextBox txtPalavraOuFrase;
        private System.Windows.Forms.Button btnPalindromo;
    }
}