﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            if (txtPalavraOuFrase.Text.Length <= 50)
            {
                string textoLimpo = Regex.Replace(txtPalavraOuFrase.Text, @"\s", "").ToUpper();
                string comAcentos = "ÄÅÁÂÀÃäáâàãÉÊËÈéêëèÍÎÏÌíîïìÖÓÔÒÕöóôòõÜÚÛüúûùÇç";
                string semAcentos = "AAAAAAaaaaaEEEEeeeeIIIIiiiiOOOOOoooooUUUuuuuCc";
                for (int i = 0; i < comAcentos.Length; i++)
                {
                    textoLimpo = textoLimpo.Replace(comAcentos[i].ToString(), semAcentos[i].ToString());
                }                

                char[] charArray = textoLimpo.ToCharArray();
                Array.Reverse(charArray);
                string textoInverso = new string(charArray);

                if(textoLimpo.Equals(textoInverso))
                {
                    MessageBox.Show("É um palíndromo!");
                    
                }else
                {
                    MessageBox.Show("Não é um palíndromo!");
                }
                
            }
            else
            {
                MessageBox.Show("Digite até 50 caracteres!");
            }
        }
    }
}
