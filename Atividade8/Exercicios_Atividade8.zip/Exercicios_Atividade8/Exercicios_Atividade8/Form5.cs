﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade8
{
    public partial class frmExercicio4 : Form
    {
        public int Producao = 0;
        public double Salario = 0;
        public double Gratificacao = 0;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnSalarioBruto_Click(object sender, EventArgs e)
        {
            int B = Producao >= 100 ? 1 : 0;
            int C = Producao >= 120 ? 1 : 0;
            int D = Producao >= 150 ? 1 : 0;

            Double salarioBruto = Salario + Salario * (0.05 * B + 0.1 * C + 0.1 * D) + Gratificacao;

            salarioBruto = salarioBruto > 7000 && (Producao < 150 || Gratificacao == 0) ? 7000 : salarioBruto;

            MessageBox.Show("Salário Bruto = R$ " + salarioBruto);

        }

        private void txtProducao_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtProducao.Text, out Producao))
            {
                MessageBox.Show("Número Incorreto!");
                txtProducao.Text = "";
                txtProducao.Focus();
            }
        }

        private void txtSalario_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtSalario.Text, out Salario))
            {
                MessageBox.Show("Número Incorreto!");
                txtSalario.Text = "";
                txtSalario.Focus();
            }
        }

        private void txtGratificacao_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtGratificacao.Text, out Gratificacao))
            {
                MessageBox.Show("Número Incorreto!");
                txtGratificacao.Text = "";
                txtGratificacao.Focus();
            }
        }
    }
}
