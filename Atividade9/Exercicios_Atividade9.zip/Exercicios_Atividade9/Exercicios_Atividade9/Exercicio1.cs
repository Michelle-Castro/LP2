﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade9
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite 20 números:, Posição: "+(i+1), "Inserir números");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int elemento in vetor)
                auxiliar += elemento + "\n"; 
            MessageBox.Show(auxiliar);

        }
    }
}
