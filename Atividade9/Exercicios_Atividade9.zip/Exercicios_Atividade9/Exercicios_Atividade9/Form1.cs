﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade9
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            frmExercicio1 FRM1 = new frmExercicio1();
            FRM1.ShowDialog();
            
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            frmExercicio2 FRM2 = new frmExercicio2();
            FRM2.ShowDialog();
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            frmExercicio3 FRM3 = new frmExercicio3();
            FRM3.ShowDialog();
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 FRM4 = new frmExercicio4();
            FRM4.ShowDialog();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 FRM5 = new frmExercicio5();
            FRM5.ShowDialog();
        }

        private void btnExercicio6_Click(object sender, EventArgs e)
        {
            frmExercicio6 FRM6 = new frmExercicio6();
            FRM6.ShowDialog();
        }
    }
}
