﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade9
{
    public partial class frmExercicio2 : Form
    {

        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnQuantidadeMercadorias_Click(object sender, EventArgs e)
        {

            Double faturamento = 0;
            Double[] vetorQuantidade = new Double[10];
            Double[] vetorPreco = new Double[10];
            string auxiliar, auxiliar2;

            for (var i = 0; i < vetorQuantidade.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade do produto: " + (i + 1), "Entrada de Dados");

                if (!Double.TryParse(auxiliar, out vetorQuantidade[i]))
                {
                    MessageBox.Show("Quantidade Inválida!");
                    i--;
                }
            }

            for (var i = 0; i < vetorPreco.Length; i++)
            {
                auxiliar2 = Interaction.InputBox("Digite o preço do produto: " + (i + 1), "Entrada de Dados");

                if (!Double.TryParse(auxiliar2, out vetorPreco[i]))
                {
                    MessageBox.Show("Preço Inválido!");
                    i--;
                }
            }

            for(var cont = 0; cont <= 9; cont++)
            {
                faturamento += vetorQuantidade[cont] * vetorPreco[cont];
                
            }

            MessageBox.Show("O faturamento mensal é: R$ " + faturamento.ToString());
        }

        private void btnFaturamentoMensal_Click(object sender, EventArgs e)
        {
           
        }
    }
}
