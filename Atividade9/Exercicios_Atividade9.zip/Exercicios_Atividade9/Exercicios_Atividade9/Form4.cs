﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade9
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnAlunos_Click(object sender, EventArgs e)
        {
            ArrayList listaAlunos = new ArrayList();
            listaAlunos.Add("Ana");
            listaAlunos.Add("André");
            listaAlunos.Add("Débora");
            listaAlunos.Add("Fátima");
            listaAlunos.Add("João");
            listaAlunos.Add("Janete");
            listaAlunos.Add("Otávio");
            listaAlunos.Add("Marcelo");
            listaAlunos.Add("Pedro");
            listaAlunos.Add("Thais");
            
            MessageBox.Show("Segue lista de alunos: ");

            for (int i = 0; i < listaAlunos.Count; i++)
            {

                if(listaAlunos[i].Equals("Otávio"))
                {
                    listaAlunos.Remove("Otávio");
                    
                } else
                {
                    MessageBox.Show(listaAlunos[i].ToString());
                }
            }
        }
    }
}
