﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade9
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnInserirNotas_Click(object sender, EventArgs e)
        {
            double[,] boletim = new double[20, 3];
            string auxiliar;
            double mediaNotas = 0;

            for (var aluno = 0; aluno < 20; aluno++)
            {
                mediaNotas = 0;

                for (var nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox("Insira a nota " + (nota + 1).ToString() + " do aluno(a) " + (aluno + 1).ToString(), "Dados:");

                    if (!double.TryParse(auxiliar, out boletim[aluno, nota]) || (auxiliar.Equals("")))
                    {
                        MessageBox.Show("Nota inválida!");
                        nota--;
                    }
                                        
                    mediaNotas += boletim[aluno, nota];
                }
                Alunos.Items.Add("Aluno(a) " + (aluno + 1) + ": Média: " + (mediaNotas/3).ToString("N1"));
                             
            }
        }
    }
}
