﻿
namespace Exercicios_Atividade9
{
    partial class frmExercicio6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Dados = new System.Windows.Forms.ListBox();
            this.btnCadastrarNomes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Dados
            // 
            this.Dados.FormattingEnabled = true;
            this.Dados.ItemHeight = 15;
            this.Dados.Location = new System.Drawing.Point(499, 28);
            this.Dados.Name = "Dados";
            this.Dados.Size = new System.Drawing.Size(252, 304);
            this.Dados.TabIndex = 0;
            // 
            // btnCadastrarNomes
            // 
            this.btnCadastrarNomes.Location = new System.Drawing.Point(185, 118);
            this.btnCadastrarNomes.Name = "btnCadastrarNomes";
            this.btnCadastrarNomes.Size = new System.Drawing.Size(113, 66);
            this.btnCadastrarNomes.TabIndex = 1;
            this.btnCadastrarNomes.Text = "Cadastrar Nomes";
            this.btnCadastrarNomes.UseVisualStyleBackColor = true;
            this.btnCadastrarNomes.Click += new System.EventHandler(this.btnCadastrarNomes_Click);
            // 
            // frmExercicio6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 363);
            this.Controls.Add(this.btnCadastrarNomes);
            this.Controls.Add(this.Dados);
            this.Name = "frmExercicio6";
            this.Text = "Exercício 6";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox Dados;
        private System.Windows.Forms.Button btnCadastrarNomes;
    }
}