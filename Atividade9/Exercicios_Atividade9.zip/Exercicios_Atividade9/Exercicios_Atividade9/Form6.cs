﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercicios_Atividade9
{
    public partial class frmExercicio6: Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnCadastrarNomes_Click(object sender, EventArgs e)
        {
            string[] nomesCompletos = new string[7];
            int[] numeroCaracteres = new int[200];
            string auxiliar;
            

            for(int i = 0; i < nomesCompletos.Length; i++)
            {
                auxiliar = Interaction.InputBox("Cadastre os Nomes Completos: ", "Dados: ");

                numeroCaracteres[i] = (auxiliar.Replace(" ", String.Empty)).Length;

                Dados.Items.Add("O nome: " + (auxiliar) + " tem " + (numeroCaracteres[i]) + " caracteres.");
            }

        }
    }
}
