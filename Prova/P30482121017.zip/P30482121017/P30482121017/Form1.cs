﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P30482121017
{
    public partial class frmInicio : Form
    {
        public frmInicio()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] vendas = new double[7, 4];
            string auxiliar;
            double totalVendas = 0, VendasGeral = 0;
            
            for (var cont = 0; cont < 7; cont++)
            {
                for (var cont2 = 0; cont2 < 4; cont2++)
                {
                    auxiliar = Interaction.InputBox("Insira as vendas do mês " + (cont + 1).ToString() + " da semana " + (cont2 + 1).ToString(), "Dados:");

                    if (auxiliar == "")
                        break;

                    if (!double.TryParse(auxiliar, out vendas[cont, cont2]))
                    {
                        MessageBox.Show("Valor inválido!");
                        cont2--;
                    }
                    else
                    {
                        Resultado.Items.Add("Total do mês:" + (cont + 1).ToString() + " Semana:" + ( + 1).ToString() + " " + vendas[cont, cont2].ToString("C2"));
                    }
                    totalVendas += vendas[cont, cont2];
                }
                Resultado.Items.Add(">> Total do mês:" + totalVendas.ToString("C2"));
                Resultado.Items.Add("-------------");
                VendasGeral += totalVendas;
                totalVendas = 0;
            }
            Resultado.Items.Add(">> Total Geral:" + VendasGeral.ToString("C2"));
        }
    }
}

